import React from "react";

const EmployeeContext = React.createContext()
//const { UserProvider, UserConsumer } = UserContext
//export UserProvider
//export UserConsumer

export default EmployeeContext